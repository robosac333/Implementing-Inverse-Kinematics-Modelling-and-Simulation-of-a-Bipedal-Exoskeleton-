#!/usr/bin/env python3
# -*- coding: utf-8 -*-
import rclpy
from rclpy.node import Node
from sensor_msgs.msg import Imu
import math
from rclpy.qos import QoSProfile
from rclpy.qos import ReliabilityPolicy, HistoryPolicy

from geometry_msgs.msg import Quaternion
from std_msgs.msg import  MultiArrayLayout, MultiArrayDimension, Float64MultiArray
from sensor_msgs.msg import JointState

from tf_transformations import euler_from_quaternion
import numpy as np


import sympy as sp
import matplotlib.pyplot as plt
from mpl_toolkits.mplot3d import Axes3D
import numpy as np


# global dx, dy, yaw, 
global θrad, αrad, a, d
global θ1, θ2, θ3

θrad, αrad, a, d = sp.symbols('θdeg αdeg a d')
θ1, θ2, θ3 = sp.symbols('θ1 θ2 θ3')

# Created a function to print the Transformation Matrix of each joint wrt previous joint

def Transform_matrix(θrad, αrad, a, d):
    return sp.Matrix([
        [sp.cos(θrad), -sp.sin(θrad) * sp.cos(αrad), sp.sin(θrad) * sp.sin(αrad), a * sp.cos(θrad)],
        [sp.sin(θrad), sp.cos(θrad) * sp.cos(αrad), -sp.cos(θrad) * sp.sin(αrad), a * sp.sin(θrad)],
        [0, sp.sin(αrad), sp.cos(αrad), d],
        [0, 0, 0, 1]
    ])

#Writing all the original transformation matrices of each joint wrt the previous joints

def T1(θ1_):
    return Transform_matrix((θ1_ + sp.pi/2), 0, 30, -163.4)

def T2(θ2_):
    return Transform_matrix(θ2_, sp.pi, -522, 0)

def T3(θ3_):
    return Transform_matrix(θ3_, - sp.pi/2, -460, 0)

def main(args=None):
        #Printing all the original transformation matrices of each joint wrt the base
        T20 = T1(θ1) * T2(θ2)
        T30 = T1(θ1) * T2(θ2) * T1(θ3)

        # From the final transformation matrix, extracting the first three members of the final matrix
        # to get the position of the end effector wrt base
        P6 = T30[:3, -1]

        # Declaring all the partial derivatives of the Position of end effector wrt the joint angles
        dP_dθ1 = P6.diff(θ1)
        dP_dθ2 = P6.diff(θ2)
        dP_dθ3 = P6.diff(θ3)

        # Obtaining the axis vector Z for each joint
        Z1 = T1(θ1)[:3, 2]
        Z2 = T20[:3, 2]
        Z3 = T30[:3, 2]

        # Jacobian matrix using the seconf method
        J = sp.Matrix([
            [dP_dθ1, dP_dθ2, dP_dθ3],
            [Z1, Z2, Z3]
        ])

        # Printing out the Jacobian Matrix
        # sp.pprint(J)
        # J0 = J.subs({
        #     θ1: 0, θ2: 0, θ3: 0
        # })
        # sp.pprint(J0)

        # Declared some initial angles in order to avoid singularity while calculating the Jacobian inverse
        q = sp.Matrix([0, 0, 0])

        rclpy.init(args=args)

        node1 = rclpy.create_node('vel_pos_publisher_node1')
        joint_position_pub1 =   node1.create_publisher(Float64MultiArray, '/position_controller/commands', 10)
        link_velocities_pub1 = node1.create_publisher(Float64MultiArray, '/velocity_controller/commands', 10)
        joint_state_pub1 =   node1.create_publisher(JointState, '/joint_states', 10)

        node2 = rclpy.create_node('vel_pos_publisher_node2')
        joint_position_pub2 =   node1.create_publisher(Float64MultiArray, '/position_controller/commands', 10)
        link_velocities_pub2 = node1.create_publisher(Float64MultiArray, '/velocity_controller/commands', 10)
        joint_state_pub2 =   node1.create_publisher(JointState, '/joint_states', 10)


# Right Leg Velocities
        while q[0] < 0.523599 and rclpy.ok(): 

            link_velocities = Float64MultiArray(layout=MultiArrayLayout(
                dim=[MultiArrayDimension(label="link_velocities", size=4, stride=1)],
                data_offset=0
            ))

            linear_velocity = 1.0
            link_velocities.data = [linear_velocity, linear_velocity, linear_velocity]

            # joint_positions = Float64MultiArray(layout=MultiArrayLayout(
            #     dim=[MultiArrayDimension(label="joint_positions", size=2, stride=1)],
            #     data_offset=0
            # ))        
            # joint_positions.data = [steer_angle, steer_angle]   
            # joint_position_pub.publish(joint_positions)
            link_velocities_pub1.publish(link_velocities)       

#  Left Leg velocities
        # while q[0] > 0.523599 and rclpy.ok(): 


        #     link_velocities = Float64MultiArray(layout=MultiArrayLayout(
        #         dim=[MultiArrayDimension(label="link_velocities", size=4, stride=1)],
        #         data_offset=0
        #     ))
        #     link_velocities.data = [-linear_velocity, linear_velocity, -linear_velocity, linear_velocity]

        #     # joint_positions = Float64MultiArray(layout=MultiArrayLayout(
        #     #     dim=[MultiArrayDimension(label="joint_positions", size=2, stride=1)],
        #     #     data_offset=0
        #     # ))        
        #     # joint_positions.data = [steer_angle, steer_angle]   
        #     # joint_position_pub.publish(joint_positions)
        #     link_velocities_pub2.publish(link_velocities)  


        # node1.get_logger().info('Stopping Car position tracking')
        # steer_angle = 0.0
        # linear_velocity = 0.0
        # link_velocities = Float64MultiArray(layout=MultiArrayLayout(
        #     dim=[MultiArrayDimension(label="link_velocities", size=4, stride=1)],
        #     data_offset=0
        # ))
        # link_velocities.data = [-linear_velocity, linear_velocity, -linear_velocity, linear_velocity]

        # joint_positions = Float64MultiArray(layout=MultiArrayLayout(
        #     dim=[MultiArrayDimension(label="joint_positions", size=2, stride=1)],
        #     data_offset=0
        # ))          
        # joint_positions.data = [steer_angle, steer_angle]         
        # joint_position_pub.publish(joint_positions)
        linear_velocity = 0
        link_velocities_pub2.publish(link_velocities)
        node1.get_logger().info('Stopping the Car')
        
        rclpy.spin_once(node1)
        node1.destroy_node()
        rclpy.shutdown()

if __name__ == '__main__':
    main()



# def imu_callback( msg):
#     global wheel_radius, steer_angle
#     global dx_, dy_, yaw
#     steer_angle = 0.0
#     wheel_radius = 4.0
#     last_timestamp = None
#     last_timestamp =  msg.header.stamp.sec +  msg.header.stamp.nanosec / 1e9
#     if  last_timestamp is not None:
#         current_timestamp =  msg.header.stamp.sec +  msg.header.stamp.nanosec / 1e9
#         dt = current_timestamp -  last_timestamp

#         orientation =  msg.orientation
#         q = [orientation.x, orientation.y, orientation.z, orientation.w]

#         roll, pitch, yaw = euler_from_quaternion(q)

#         # Assigning initial_agular Velocity to neglect the errie imu_angular velocity message
#         angular_velocity_ = 25.0
#         # Estimate position in x and y based on linear acceleration
#         dx_ =  wheel_radius *  angular_velocity_ * dt
#         dy_ =  wheel_radius *  angular_velocity_  * dt
#         dx_ += dx_
#         dy_ += dy_
#         a = []
#         a.append(dx_)
#         print(f"dx = { dx_}, radius = {wheel_radius}, omega={angular_velocity_}, yaw={ yaw}, dt={dt}"  )

# last_timestamp =  msg.header.stamp.sec +  msg.header.stamp.nanosec / 1e9